define(['./dialog'], function(Dialog) {
    var SettingsPage = Dialog.extend({
        init: function() {

        }
    });
});
