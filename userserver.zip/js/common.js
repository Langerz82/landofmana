cls = require("./lib/class");
_ = require('underscore');

GameTypes = require("../shared/js/gametypes");
ItemTypes = require("../shared/js/itemtypes");
Types = GameTypes;
Utils = require('./utils');

AppearanceData = require('./data/appearancedata');
